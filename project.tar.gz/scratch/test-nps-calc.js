const yandexFormIds = {
  day1Input: "69b447a8e010db3d6b505b69",
  day1Output: "69b5762790fa7b47e155853c",
  day2: "69b5799f49af4761ee2057c6"
};

const token = "OAuth y0__xCGrufZBhjEm0AgibqbhReNTwlec-qB4RoeBDD4ffOerf6B-A";
const orgId = "bpf04hd74akq183mc4f5";

function findScore(value) {
  if (value === null || value === undefined) return null;
  if (Array.isArray(value)) {
    for (const item of value) {
      const score = findScore(item);
      if (score !== null) return score;
    }
    return null;
  }
  const str = String(value).trim();
  if (str === "") return null;
  
  // Strict matching
  if (/^\d+$/.test(str)) {
    const num = Number(str);
    if (num >= 0 && num <= 10) return num;
  }
  return null;
}

async function run() {
  const formId = yandexFormIds.day1Output;
  const response = await fetch(`https://api.forms.yandex.net/v1/surveys/${formId}/answers?page_size=1000`, {
    headers: {
      Accept: "application/json",
      "X-Cloud-Org-Id": orgId,
      "Authorization": token
    }
  });
  const data = await response.json();

  const columns = data.columns || [];
  const npsColIndexes = [];
  columns.forEach((col, idx) => {
    const text = (col.text || "").toLowerCase();
    const slug = (col.slug || "").toLowerCase();
    if (
      text.includes("nps") || 
      text.includes("рекоменд") || 
      text.includes("насколько готовы") ||
      text.includes("насколько вы готовы") ||
      slug.includes("nps") || 
      slug.includes("score")
    ) {
      npsColIndexes.push(idx);
    }
  });

  console.log("NPS columns indices:", npsColIndexes);

  const scores = [];
  data.answers.forEach((ans) => {
    const createdDate = new Date(ans.created).toISOString().split('T')[0];
    if (createdDate !== "2026-06-03") return;
    
    // Only check matched NPS columns
    for (const idx of npsColIndexes) {
      const item = ans.data?.[idx];
      const val = item ? item.value : null;
      const score = findScore(val);
      if (score !== null) {
        scores.push({ id: ans.id, score, raw: val });
        break;
      }
    }
  });

  console.log("Extracted scores:", scores);
  const promoters = scores.filter((s) => s.score >= 9).length;
  const passives = scores.filter((s) => s.score >= 7 && s.score <= 8).length;
  const detractors = scores.filter((s) => s.score <= 6).length;
  const nps = Math.round(((promoters - detractors) / scores.length) * 100);
  console.log(`Summary: total=${scores.length}, promoters=${promoters}, passives=${passives}, detractors=${detractors}, nps=${nps}`);
}

run().catch(console.error);
