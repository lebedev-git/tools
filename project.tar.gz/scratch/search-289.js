const fs = require('fs');

const logPath = 'C:/Users/Andey/.gemini/antigravity/brain/510cdccc-0a8b-429b-b35d-6ce89079d639/.system_generated/logs/transcript.jsonl';
const content = fs.readFileSync(logPath, 'utf8');

const matches = content.match(/"content":".*?289:.*?"/);
if (matches) {
  console.log("Found 289:", matches[0].slice(0, 500));
} else {
  console.log("Not found 289 in content");
}
