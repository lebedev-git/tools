async function run() {
  const url = "https://qwen.aikit.club/v1/models";
  const key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjlhNzQzOTljLTcxMWYtNDA2MS05NWFjLTFkOGUxODY1NmZmZiIsImxhc3RfcGFzc3dvcmRfY2hhbmdlIjoxNzcwOTc1NTM5LCJleHAiOjE3ODIyODQ5MjV9.QoWCSkq07C7Q_cuxoGoL_BgaAkQ1MdhHu90vBN0JXeo";
  
  try {
    const res = await fetch(url, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${key}`
      }
    });
    const body = await res.json();
    const allModels = body.data || [];
    console.log("Total models:", allModels.length);
    const imageModels = allModels.filter(m => 
      m.id.includes("image") || 
      m.id.includes("draw") || 
      m.id.includes("flux") || 
      m.id.includes("dall") || 
      m.id.includes("diffusion") ||
      m.id.includes("sd") ||
      (m.info?.meta?.capabilities && Object.keys(m.info.meta.capabilities).some(k => k.includes("image") || k.includes("draw")))
    );
    console.log("Image/Draw Models found:");
    imageModels.forEach(m => {
      console.log(`- ID: ${m.id}, Name: ${m.name}`);
    });
  } catch (err) {
    console.error("Error:", err.message);
  }
}
run();
