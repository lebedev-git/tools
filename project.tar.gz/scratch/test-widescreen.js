async function run() {
  console.log("Testing gpt-image-2 with widescreen 1792x1024 resolution...");
  try {
    const res = await fetch("https://codex.sale/v1/images/generations", {
      method: "POST",
      headers: {
        "Authorization": "Bearer sk-clb-3APylzCeyo_r4Lapmp_eLgQl5Ul973_z6QLyRWD1L1A",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-image-2",
        prompt: "Flat modern 16:9 infographic dashboard in minimalist dark mode style. Clean typography, business metrics blocks, charts. Include legible English labels like 'Day 1', 'Day 2', 'NPS', 'Satisfaction'.",
        n: 1,
        size: "1792x1024"
      })
    });
    console.log("Status:", res.status);
    const body = await res.json();
    if (body.error) {
      console.log("Error:", body.error.message);
    } else {
      console.log("Success! Generated image.");
      console.log("Revised prompt:", body.data?.[0]?.revised_prompt);
      console.log("Data size (bytes):", body.data?.[0]?.b64_json?.length);
    }
  } catch (err) {
    console.error("Error:", err.message);
  }
}
run();
