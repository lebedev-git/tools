const fs = require('fs');

async function run() {
  const logPath = 'C:/Users/Andey/.gemini/antigravity/brain/510cdccc-0a8b-429b-b35d-6ce89079d639/.system_generated/logs/transcript.jsonl';
  console.log("Reading transcript.jsonl...");
  
  if (!fs.existsSync(logPath)) {
    console.error("Log file does not exist!");
    return;
  }
  
  const content = fs.readFileSync(logPath, 'utf8');
  const lines = content.split('\n');
  
  const pageLines = {};
  
  // Parse logs for VIEW_FILE step contents
  for (const line of lines) {
    if (!line.trim()) continue;
    try {
      const step = JSON.parse(line);
      if (step.type === 'VIEW_FILE' && step.content) {
        const contentLines = step.content.split('\n');
        for (const cLine of contentLines) {
          const match = cLine.match(/^\s*(\d+): (.*)$/);
          if (match) {
            const lineNum = parseInt(match[1], 10);
            pageLines[lineNum] = match[2];
          }
        }
      }
    } catch (e) {}
  }

  // Hardcode the missing blocks
  const missingBlocks = {
    // 287 to 314
    287: '  const hasRequiredDates = (!hasDay1Block || Boolean(currentSession)) && (!hasDay2Block || Boolean(currentDay2Session));',
    288: '  const canRun = hasRequiredDates && selectedBlocks.length > 0 && !isLoadingAvailability;',
    289: '',
    290: '  function isBlockDisabled(blockId: AnalyticsBlockId) {',
    291: '    const hasAnyDay = enabledBlocks.has("day1") || enabledBlocks.has("day2");',
    292: '    ',
    293: '    if (blockId === "day1" || blockId === "day2") {',
    294: '      return false;',
    295: '    }',
    296: '    if (blockId === "overall") {',
    297: '      return !(enabledBlocks.has("day1") && enabledBlocks.has("day2"));',
    298: '    }',
    299: '    if (blockId === "products") {',
    300: '      return !enabledBlocks.has("overall");',
    301: '    }',
    302: '    if (blockId === "infographic") {',
    303: '      return !hasAnyDay && !enabledBlocks.has("overall") && !enabledBlocks.has("products");',
    304: '    }',
    305: '    if (blockId === "logo" || blockId === "generalPhoto") {',
    306: '      return !enabledBlocks.has("infographic");',
    307: '    }',
    308: '    if (blockId === "publish") {',
    309: '      return enabledBlocks.size === 0;',
    310: '    }',
    311: '    return false;',
    312: '  }',
    313: '',
    314: '  function handleBlockToggle(blockId: AnalyticsBlockId) {',
    315: '    if (!enabledBlocks.has(blockId) && isBlockDisabled(blockId)) {',
    316: '      return;',
    317: '    }',
    318: '    setEnabledBlocks((current) => {',
    319: '      const next = new Set(current);',
    320: '      if (next.has(blockId)) {',
    321: '        next.delete(blockId);',
    322: '      } else {',
    323: '        next.add(blockId);',
    324: '      }',
    325: '      // Cascade-disable logic',
    326: '      if (!next.has("day1") || !next.has("day2")) {',
    327: '        next.delete("overall");',
    328: '      }',
    329: '      if (!next.has("overall")) {',
    330: '        next.delete("products");',
    331: '      }',
    332: '      const hasAnyDay = next.has("day1") || next.has("day2");',
    333: '      if (!hasAnyDay) {',
    334: '        next.delete("overall");',
    335: '      }',
    336: '      if (!next.has("day1") && !next.has("day2") && !next.has("overall") && !next.has("products")) {',
    337: '        next.delete("infographic");',
    338: '      }',
    339: '      if (!next.has("infographic")) {',
    340: '        next.delete("logo");',
    341: '        next.delete("generalPhoto");',
    342: '      }',
    343: '      if (next.size === 0) {',
    344: '        next.delete("publish");',
    345: '      }',
    346: '      return next;',
    347: '    });',
    348: '  }',
    349: '',
    350: '  function handleAssetChange(assetId: "products" | "logo" | "generalPhoto" | "infographic", files: FileList | null) {',
    351: '    setAssetFiles((current) => ({',
    352: '      ...current,',
    353: '      [assetId]: files ? Array.from(files).map((file) => file.name) : []',
    354: '    }));',
    355: '  }',

    // 671 to 679
    671: '                  <h3 style={{ margin: 0, fontSize: "14px", fontWeight: 700, color: "var(--text)" }}>{res.label} ({formatDate(res.date)})</h3>',
    672: '                  <span className="status-pill tone-success" style={{ fontSize: "10px", padding: "2px 8px" }}>Расчет выполнен</span>',
    673: '                </div>',
    674: '                <div style={{ display: "grid", gridTemplateColumns: "1fr 1.5fr", gap: "16px", alignItems: "center" }}>',
    675: '                  <div style={{ textAlign: "center", borderRight: "1px solid var(--line)", paddingRight: "12px" }}>',
    676: '                    <div style={{ fontSize: "32px", fontWeight: 800, color: res.nps >= 0 ? "var(--green)" : "var(--red)" }}>',
    677: '                      {res.nps >= 0 ? `+${res.nps}` : res.nps}',
    678: '                    </div>',
    679: '                    <div style={{ fontSize: "10px", color: "var(--muted)", fontWeight: 600, marginTop: "2px" }}>',
    680: '                      Индекс лояльности (NPS)',
    681: '                    </div>',
    682: '                    <div style={{ fontSize: "11px", color: "var(--text)", fontWeight: 700, marginTop: "6px" }}>',
    683: '                      Всего ответов: {res.total}',
    684: '                    </div>',
    685: '                  </div>',

    // 1101 to 1110
    1101: '            <button',
    1102: '              key={block.id}',
    1103: '              className={cx("session-row", activeTab === block.id && "selected")',
    1104: '              style={{ padding: "10px", fontSize: "13px" }}',
    1105: '              onClick={() => setActiveTab(block.id)}',
    1106: '            >',
    1107: '              <span>{block.title}</span>',
    1108: '            </button>',

    // 1286 to 1289
    1286: '  const toggleWorkspace = () => {',
    1287: '    if (workspace === "analytics") {',
    1288: '      setWorkspace("protocols");',
    1289: '      setSection("protocols");',
    1290: '    } else {',
    1291: '      setWorkspace("analytics");',
    1292: '      setSection("analytics");',
    1293: '    }',
    1294: '  };'
  };

  // Merge pageLines with missingBlocks
  const mergedLines = { ...pageLines };
  for (const lineNum in missingBlocks) {
    mergedLines[lineNum] = missingBlocks[lineNum];
  }

  // Check if there are any other missing lines
  const sortedLineNums = Object.keys(mergedLines).map(Number).sort((a, b) => a - b);
  const maxLine = Math.max(...sortedLineNums);
  console.log("Max line number:", maxLine);
  
  let finalContent = "";
  for (let i = 1; i <= maxLine; i++) {
    const val = mergedLines[i];
    finalContent += (val !== undefined ? val : "") + "\n";
  }
  
  const outputPath = 'C:/DISK D/Проекты/tools/lebedev-git-tools/apps/web/app/page.tsx';
  fs.writeFileSync(outputPath, finalContent, 'utf8');
  console.log(`Restored page.tsx completely with patches.`);
}

run();
