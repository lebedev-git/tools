async function run() {
  console.log("Fetching models from Codex Sale...");
  try {
    const res = await fetch("https://codex.sale/v1/models", {
      method: "GET",
      headers: {
        "Authorization": "Bearer sk-clb-3APylzCeyo_r4Lapmp_eLgQl5Ul973_z6QLyRWD1L1A",
      }
    });
    console.log("Status:", res.status);
    const body = await res.json();
    console.log("Body:", JSON.stringify(body, null, 2));
  } catch (err) {
    console.error("Error:", err);
  }
}
run();
