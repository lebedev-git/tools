async function run() {
  const url = "http://automation-codex-service:3007/codex-internal";
  console.log(`Pinging internal image service at ${url}...`);
  try {
    const res = await fetch(url, {
      method: "GET",
      signal: AbortSignal.timeout(5000)
    });
    console.log("Status:", res.status);
    const text = await res.text();
    console.log("Response text:", text.slice(0, 500));
  } catch (err) {
    console.error("Error pinging internal service:", err.message);
  }
}
run();
