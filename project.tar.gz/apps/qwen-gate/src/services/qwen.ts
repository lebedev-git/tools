import { getQwenHeaders } from './playwright.ts';
import crypto from 'node:crypto';
import { withRetry, CircuitBreaker, CircuitOpenError } from '../utils/retry.ts';
import { throttleAccount, pickAccount, decrementInFlight } from './auth.ts';
import { createNetworkEntry, recordResponse, recordStreamChunk, completeEntry, errorEntry } from './networkDebug.ts';
import { config } from './configService.ts';
import { logQwenRequest, logQwenResponse } from './qwenLogger.ts';
import { logStore } from './logStore.ts';

export { fetchQwenModels, disableNativeTools, disablePersonalization, setCustomInstruction, configureAccount, deleteAllChats } from './qwenModels.ts';

// Shared URL constants for Qwen API
export const QWEN_API_BASE = 'https://chat.qwen.ai';
export const QWEN_CHAT_COMPLETIONS_URL = `${QWEN_API_BASE}/api/v2/chat/completions`;
export const QWEN_SETTINGS_URL = `${QWEN_API_BASE}/api/v2/users/user/settings/update`;
export const QWEN_CHATS_URL = `${QWEN_API_BASE}/api/v2/chats/`;
export const QWEN_MODELS_URL = `${QWEN_API_BASE}/api/models`;

export class RetryableQwenStreamError extends Error {
  readonly retryAfterMs: number;
  constructor(message: string, retryAfterMs: number) {
    super(message);
    this.name = 'RetryableQwenStreamError';
    this.retryAfterMs = retryAfterMs;
  }
}

export class QwenUpstreamError extends Error {
  readonly upstreamCode: string;
  readonly upstreamStatus: number;
  constructor(message: string, upstreamCode: string, upstreamStatus: number) {
    super(message);
    this.name = 'QwenUpstreamError';
    this.upstreamCode = upstreamCode;
    this.upstreamStatus = upstreamStatus;
  }
}

class UpstreamStatusError extends Error {
  readonly status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = 'UpstreamStatusError';
    this.status = status;
  }
}

export interface QwenMessage {
  fid: string;
  parentId: string | null;
  childrenIds: string[];
  role: 'user' | 'assistant' | 'function';
  content: string | Record<string, unknown>;
  user_action: string;
  files: unknown[];
  timestamp: number;
  models: string[];
  chat_type: string;
  feature_config: Record<string, unknown>;
  extra: Record<string, unknown>;
  sub_chat_type: string;
  parent_id: string | null;
  // Function-specific fields (only for role: 'function')
  model?: string;
  modelName?: string;
  modelIdx?: number;
  userContext?: unknown;
  info?: Record<string, unknown>;
}

export interface QwenPayload {
  stream: boolean;
  version: string;
  incremental_output: boolean;
  chat_id: string | null;
  chat_mode: string;
  model: string;
  parent_id: string | null;
  messages: QwenMessage[];
  timestamp: number;
}

export interface QwenStreamResult {
  stream: ReadableStream;
  headers: Record<string, string>;
  uiSessionId: string;
  accountEmail?: string;
  abortController: AbortController;
  qwenLogFile?: string;
}

const QWEN_FETCH_TIMEOUT_MS = parseInt(config.get('QWEN_FETCH_TIMEOUT_MS', '30000'), 10);

// Cache Intl.DateTimeFormat — avoids re-creating per request (expensive)
const cachedTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

function createFetchTimeout(): { controller: AbortController; cleanup: () => void } {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), QWEN_FETCH_TIMEOUT_MS);
  return { controller, cleanup: () => clearTimeout(timeout) };
}

const qwenCircuitBreaker = new CircuitBreaker('qwen-api', {
  failureThreshold: 5,
  resetTimeoutMs: 30_000,
  halfOpenMaxAttempts: 1,
});

export async function createQwenStream(
  messages: QwenMessage[],
  enableThinking: boolean,
  modelId: string,
  chatId?: string,
  parentId?: string | null,
  accountEmail?: string,
  tools?: unknown[],
  toolChoice?: unknown
): Promise<QwenStreamResult> {
  const actualParentId: string | null = parentId !== undefined ? parentId : null;
  const timestamp = Math.floor(Date.now() / 1000);
  const model = modelId.replace('-no-thinking', '');

  // Ensure each message has required fields
  const qwenMessages: QwenMessage[] = messages.map((msg, i) => ({
    fid: msg.fid || crypto.randomUUID(),
    parentId: msg.parentId || (i === 0 ? actualParentId : null),
    childrenIds: msg.childrenIds || [],
    role: msg.role,
    content: msg.content,
    user_action: msg.user_action || 'chat',
    files: msg.files || [],
    timestamp: msg.timestamp || timestamp,
    models: msg.models || [model],
    chat_type: msg.chat_type || 't2t',
    feature_config: msg.feature_config || {
      thinking_enabled: enableThinking,
      output_schema: 'phase',
      research_mode: 'normal',
      auto_thinking: false,
      thinking_mode: 'Thinking',
      thinking_format: 'summary',
      auto_search: false
    },
    extra: msg.extra || { meta: { subChatType: 't2t' } },
    sub_chat_type: msg.sub_chat_type || 't2t',
    parent_id: msg.parent_id ?? (i === 0 ? actualParentId : null),
    // Function-specific fields
    ...(msg.role === 'function' ? {
      model: msg.model || model,
      modelName: msg.modelName || modelId,
      modelIdx: msg.modelIdx ?? 0,
      userContext: msg.userContext ?? null,
      info: msg.info || {},
    } : {}),
  }));

  const payload: QwenPayload = {
    stream: true,
    version: '2.1',
    incremental_output: true,
    chat_id: chatId || null,
    chat_mode: 'normal',
    model: model,
    parent_id: actualParentId,
    messages: qwenMessages,
    timestamp: timestamp + 1,
    ...(tools?.length ? { tools, tool_choice: toolChoice || 'auto', parallel_tool_calls: true } : {})
  };

  const urlObj = new URL(QWEN_CHAT_COMPLETIONS_URL);
  if (chatId) urlObj.searchParams.set('chat_id', chatId);
  const url = urlObj.href;

  const retryConfig = {
    maxRetries: Math.max(0, parseInt(config.get('RETRY_MAX_ATTEMPTS', '3'), 10)),
    baseDelayMs: Math.max(0, parseInt(config.get('RETRY_BASE_DELAY_MS', '1000'), 10)),
    maxDelayMs: Math.max(0, parseInt(config.get('RETRY_MAX_DELAY_MS', '30000'), 10)),
    backoffMultiplier: Math.max(0.1, parseFloat(config.get('RETRY_BACKOFF_MULTIPLIER', '2'))),
  };

  const retriesEnabled = config.get('RETRY_ENABLED', 'true') !== 'false';
  let currentAccountEmail = accountEmail;
  let lastDebugEntryId: string | null = null;
  const streamAbortController = new AbortController();

  function buildRequestHeaders(reqHeaders: Record<string, string>, cId?: string): Record<string, string> {
    return {
      'accept': 'application/json',
      'accept-language': 'pt-BR,pt;q=0.9',
      'content-type': 'application/json',
      'cookie': reqHeaders['cookie'],
      'origin': QWEN_API_BASE,
      'referer': cId ? `https://chat.qwen.ai/c/${cId}` : 'https://chat.qwen.ai/',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'timezone': cachedTimezone,
      'user-agent': reqHeaders['user-agent'],
      'x-accel-buffering': 'no',
      'x-request-id': crypto.randomUUID(),
      'bx-ua': reqHeaders['bx-ua'],
      'bx-umidtoken': reqHeaders['bx-umidtoken'],
      'bx-v': reqHeaders['bx-v'],
    };
  }

  async function handleErrorResponse(response: Response, debugEntryId: string): Promise<never> {
    const errText = await response.text().catch(() => '');
    const contentType = response.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      try {
        const errorJson = JSON.parse(errText);
        if (errorJson?.data?.details?.includes('chat is in progress') ||
            errorJson?.data?.details?.includes('The chat is in progress')) {
          const retryAfterMs = 2000 + Math.floor(Math.random() * 2000);
          errorEntry(debugEntryId, errorJson.data.details);
          throw new RetryableQwenStreamError(`Qwen: ${errorJson.data.details}`, retryAfterMs);
        }
        if (errorJson?.success === false) {
          const code = errorJson.data?.code || errorJson.code || 'UpstreamError';
          const details = errorJson.data?.details || errorJson.message || 'Qwen returned an error';
          const wait = errorJson.data?.num !== undefined
            ? ` Wait about ${errorJson.data.num} hour(s) before trying again.`
            : '';
          if (code === 'RateLimited' && currentAccountEmail) {
            const throttleMs = (errorJson.data?.num || 1) * 3600_000;
            throttleAccount(currentAccountEmail, Math.min(throttleMs, 7200_000));
            const nextAccount = await pickAccount();
            if (nextAccount && nextAccount.email !== currentAccountEmail) {
              currentAccountEmail = nextAccount.email;
            }
            // pickAccount incremented inFlight for the new account, but we're about to throw
            // so decrement it — the caller will retry with a fresh pickAccount
            if (nextAccount) decrementInFlight(nextAccount.email);
          }
          let status: number;
          if (code === 'RateLimited') status = 429;
          else if (code === 'Not_Found') status = 404;
          else if (code === 'UpstreamError') status = 502;
          else status = 502;
          errorEntry(debugEntryId, `${code}: ${details}`);
          throw new QwenUpstreamError(`Qwen upstream error: ${code}: ${details}.${wait}`, code, status);
        }
        if (errorJson?.data?.details?.includes('is not exist') ||
            errorJson?.data?.details?.includes('not exist') ||
            errorJson?.data?.details?.includes('does not exist')) {
          errorEntry(debugEntryId, errorJson.data.details);
          throw new RetryableQwenStreamError(`Qwen: ${errorJson.data.details}`, 0);
        }
      } catch (parseOrRetryError) {
        if (parseOrRetryError instanceof RetryableQwenStreamError ||
            parseOrRetryError instanceof QwenUpstreamError) {
          throw parseOrRetryError;
        }
      }
    }
    const sanitizedErrText = errText
      .replace(/eyJ[a-zA-Z0-9_-]+\.eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+/g, '[JWT_REDACTED]')
      .replace(/eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+/g, '[JWT_REDACTED]')
      .slice(0, 500);
    throw new UpstreamStatusError(
      `Failed to fetch from Qwen: ${response.status} ${response.statusText} - ${sanitizedErrText}`,
      response.status
    );
  }

  let makeRequestQwenLogFile: string | undefined;
  const makeRequest = async (): Promise<{ response: Response; headers: Record<string, string>; qwenLogFile?: string }> => {
    const { headers: reqHeaders } = await getQwenHeaders(currentAccountEmail);
    const requestHeaders = buildRequestHeaders(reqHeaders, chatId);
    const debugEntry = createNetworkEntry({
      url, method: 'POST', headers: requestHeaders, body: payload,
      category: 'chat', accountEmail: currentAccountEmail,
    });
    lastDebugEntryId = debugEntry.id;
    try {
      let response: Response;
      try {
        const { controller, cleanup } = createFetchTimeout();
        const onFetchAbort = () => {
          if (!streamAbortController.signal.aborted) {
            streamAbortController.abort(controller.signal.reason || new Error('Fetch timeout'));
          }
        };
        const onStreamAbort = () => {
          if (!controller.signal.aborted) {
            controller.abort(streamAbortController.signal.reason);
          }
        };
        controller.signal.addEventListener('abort', onFetchAbort);
        streamAbortController.signal.addEventListener('abort', onStreamAbort);
        try {
          const bodyStr = JSON.stringify(payload);
          if (config.get("SAVE_REQUEST_LOGS") === "true") {
            makeRequestQwenLogFile = logQwenRequest(payload, url);
          }
          response = await fetch(url, {
            method: 'POST', headers: requestHeaders,
            body: bodyStr, signal: controller.signal,
          });
          const respHeaders: Record<string, string> = {};
          response.headers.forEach((v, k) => { respHeaders[k] = v; });
          if (makeRequestQwenLogFile) logQwenResponse(makeRequestQwenLogFile, response.status, response.statusText, respHeaders, '');
        } finally {
          cleanup();
          controller.signal.removeEventListener('abort', onFetchAbort);
          streamAbortController.signal.removeEventListener('abort', onStreamAbort);
        }
      } catch (fetchErr: unknown) {
        if (fetchErr instanceof Error && fetchErr.name === 'AbortError') {
          logStore.log('warn', 'qwen', 'Request timed out');
          throw new RetryableQwenStreamError('Request timed out', 0);
        }
        const msg = fetchErr instanceof Error ? fetchErr.message : String(fetchErr);
        errorEntry(debugEntry.id, msg);
        throw fetchErr;
      }
      recordResponse(debugEntry.id, response);
      if (!response.ok || !response.body) {
        await handleErrorResponse(response, debugEntry.id);
      }
      return { response, headers: reqHeaders, qwenLogFile: makeRequestQwenLogFile };
    } catch (err) {
      errorEntry(debugEntry.id, err instanceof Error ? err.message : String(err));
      throw err;
    }
  };

  let result: { response: Response; headers: Record<string, string>; qwenLogFile?: string };
  const cbState = qwenCircuitBreaker.getState();
  if (cbState === 'open') {
    const stats = qwenCircuitBreaker.getStats();
    const retryAfterMs = Math.max(0, 30_000 - (Date.now() - stats.lastFailureTime));
    throw new CircuitOpenError(retryAfterMs);
  }
  if (retriesEnabled && retryConfig.maxRetries > 0) {
    result = await withRetry(makeRequest, { ...retryConfig, circuitBreaker: qwenCircuitBreaker });
  } else {
    result = await makeRequest();
    qwenCircuitBreaker.recordSuccess();
  }
  if (!result.response.body) {
    throw new Error(`Qwen returned empty response body (status ${result.response.status})`);
  }
  const streamDebugEntryId = lastDebugEntryId;
  const textDecoder = new TextDecoder();
  const wrappedStream = result.response.body.pipeThrough(
    new TransformStream<Uint8Array, Uint8Array>({
      transform(chunk, controller) {
        if (streamDebugEntryId) {
          recordStreamChunk(streamDebugEntryId, textDecoder.decode(chunk, { stream: true }));
        }
        controller.enqueue(chunk);
      },
      flush() {
        if (streamDebugEntryId) {
          completeEntry(streamDebugEntryId);
        }
      }
    })
  );
  return { stream: wrappedStream, headers: result.headers, uiSessionId: chatId || '', accountEmail: currentAccountEmail, abortController: streamAbortController, qwenLogFile: result.qwenLogFile };
}
