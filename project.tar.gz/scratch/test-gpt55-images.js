async function run() {
  console.log("Calling Codex Sale Image Generation API with model 'gpt-5.5'...");
  try {
    const res = await fetch("https://codex.sale/v1/images/generations", {
      method: "POST",
      headers: {
        "Authorization": "Bearer sk-clb-3APylzCeyo_r4Lapmp_eLgQl5Ul973_z6QLyRWD1L1A",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-5.5",
        prompt: "Flat modern infographic dashboard in minimalist dark mode style. Clean typography, business metrics blocks.",
        n: 1,
        size: "1024x1024"
      })
    });
    console.log("Status:", res.status);
    const body = await res.json();
    console.log("Body:", JSON.stringify(body, null, 2));
  } catch (err) {
    console.error("Error:", err);
  }
}
run();
