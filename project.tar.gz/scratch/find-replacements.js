const fs = require('fs');

async function run() {
  const logPath = 'C:/Users/Andey/.gemini/antigravity/brain/510cdccc-0a8b-429b-b35d-6ce89079d639/.system_generated/logs/transcript.jsonl';
  if (!fs.existsSync(logPath)) {
    console.error("Log file does not exist!");
    return;
  }
  const content = fs.readFileSync(logPath, 'utf8');
  const lines = content.split('\n');
  
  console.log("Analyzing steps...");
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim()) continue;
    try {
      const step = JSON.parse(line);
      if (step.tool_calls) {
        for (const tc of step.tool_calls) {
          if (tc.args && tc.args.TargetFile && tc.args.TargetFile.includes('page.tsx')) {
            console.log(`Step ${step.step_index} (${tc.name}):`);
            console.log(`  StartLine: ${tc.args.StartLine}, EndLine: ${tc.args.EndLine}`);
            console.log(`  Instruction: ${tc.args.Instruction}`);
            console.log(`  TargetContent length: ${tc.args.TargetContent ? tc.args.TargetContent.length : 0}`);
            console.log(`  ReplacementContent length: ${tc.args.ReplacementContent ? tc.args.ReplacementContent.length : 0}`);
            if (tc.args.ReplacementChunks) {
              console.log(`  Chunks count: ${tc.args.ReplacementChunks.length}`);
            }
          }
        }
      }
    } catch (e) {}
  }
}
run();
