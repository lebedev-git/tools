const apiKey = "AQ.Ab8RN6K9-8rJ2MjHnrJqE7JFrLgAt1Z3z9feX8lN4r2WqeB6sw";
const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;

async function testKey() {
  console.log("Проверяем ключ в Google Gemini API...");
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: "Hi"
              }
            ]
          }
        ]
      })
    });

    console.log(`Статус ответа: ${response.status} ${response.statusText}`);
    const data = await response.json();
    console.log("Ответ от API:", JSON.stringify(data, null, 2));

    if (response.ok) {
      console.log(">>> КЛЮЧ РАБОТАЕТ! <<<");
    } else {
      console.log(">>> КЛЮЧ НЕ РАБОТАЕТ (ошибка авторизации или запроса) <<<");
    }
  } catch (err) {
    console.error("Ошибка при выполнении запроса:", err);
  }
}

testKey();
