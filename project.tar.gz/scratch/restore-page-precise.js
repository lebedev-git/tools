const fs = require('fs');

async function run() {
  const logPath = 'C:/Users/Andey/.gemini/antigravity/brain/510cdccc-0a8b-429b-b35d-6ce89079d639/.system_generated/logs/transcript.jsonl';
  console.log("Reading transcript.jsonl from", logPath);
  
  if (!fs.existsSync(logPath)) {
    console.error("Log file does not exist!");
    return;
  }
  
  const content = fs.readFileSync(logPath, 'utf8');
  const lines = content.split('\n');
  
  const pageLines = {};
  
  for (const line of lines) {
    if (!line.trim()) continue;
    try {
      const step = JSON.parse(line);
      // Check if it's a VIEW_FILE tool response or step content containing page.tsx lines
      if (step.tool_calls) {
        const hasPageTsx = step.tool_calls.some(tc => 
          tc.name === 'view_file' &&
          tc.args && 
          tc.args.AbsolutePath && 
          tc.args.AbsolutePath.includes('page.tsx')
        );
        
        if (hasPageTsx && step.content) {
          const contentLines = step.content.split('\n');
          for (const cLine of contentLines) {
            const match = cLine.match(/^\s*(\d+): (.*)$/);
            if (match) {
              const lineNum = parseInt(match[1], 10);
              const lineContent = match[2];
              pageLines[lineNum] = lineContent;
            }
          }
        }
      }
      
      // Also look for SYSTEM step types representing the response of a tool call
      if (step.type === 'VIEW_FILE' && step.content) {
        const contentLines = step.content.split('\n');
        for (const cLine of contentLines) {
          const match = cLine.match(/^\s*(\d+): (.*)$/);
          if (match) {
            const lineNum = parseInt(match[1], 10);
            const lineContent = match[2];
            pageLines[lineNum] = lineContent;
          }
        }
      }
    } catch (e) {
      // Ignore
    }
  }
  
  const sortedLineNums = Object.keys(pageLines).map(Number).sort((a, b) => a - b);
  console.log("Precise lines found:", sortedLineNums.length);
  
  if (sortedLineNums.length > 0) {
    let finalContent = "";
    const maxLine = Math.max(...Object.keys(pageLines).map(Number));
    console.log("Max line number:", maxLine);
    for (let i = 1; i <= maxLine; i++) {
      finalContent += (pageLines[i] !== undefined ? pageLines[i] : "") + "\n";
    }
    
    const outputPath = 'C:/DISK D/Проекты/tools/lebedev-git-tools/apps/web/app/page.tsx';
    fs.writeFileSync(outputPath, finalContent, 'utf8');
    console.log(`Successfully restored precise page.tsx to ${outputPath}`);
  } else {
    console.error("Could not find any precise lines to restore.");
  }
}

run();
