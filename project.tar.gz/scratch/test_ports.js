const net = require('net');

const ip = '147.45.155.90';
const ports = [22, 222, 2222, 8022, 22022, 22222, 2200, 3000, 443, 80];

async function checkPort(port) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    socket.setTimeout(2000);
    
    socket.on('connect', () => {
      console.log(`Port ${port} is OPEN!`);
      socket.destroy();
      resolve(true);
    });
    
    socket.on('timeout', () => {
      socket.destroy();
      resolve(false);
    });
    
    socket.on('error', () => {
      socket.destroy();
      resolve(false);
    });
    
    socket.connect(port, ip);
  });
}

async function run() {
  console.log(`Сканируем порты на ${ip}...`);
  for (const port of ports) {
    await checkPort(port);
  }
  console.log('Сканирование завершено.');
}

run();
