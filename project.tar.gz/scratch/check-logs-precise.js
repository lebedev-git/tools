const fs = require('fs');

async function run() {
  const logPath = 'C:\\Users\\Andey\\.gemini\antigravity\\brain\\510cdccc-0a8b-429b-b35d-6ce89079d639\\.system_generated\\logs\\transcript.jsonl';
  if (!fs.existsSync(logPath)) {
    console.error("Log file does not exist!");
    return;
  }
  const content = fs.readFileSync(logPath, 'utf8');
  const lines = content.split('\n');
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.includes('page.tsx') && (line.includes('view_file') || line.includes('VIEW_FILE'))) {
      console.log(`Line ${i}:`, line.slice(0, 300));
    }
  }
}
run();
