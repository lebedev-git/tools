const fs = require('fs');
const path = require('path');

const logPath = 'C:\\Users\\Andey\\.gemini\\antigravity\\brain\\37ce5521-4b62-44e4-aa89-d75c2b8acf61\\.system_generated\\logs\\transcript.jsonl';
const targetFilePath = path.join(__dirname, '..', 'apps', 'web', 'app', 'page.tsx');

// Load original page.tsx
let code = fs.readFileSync(targetFilePath, 'utf-8');

function cleanString(str) {
  if (typeof str !== 'string') return str;
  let s = str;
  if (s.startsWith('"') && s.endsWith('"')) {
    try {
      s = JSON.parse(s);
    } catch {}
  }
  return s.replace(/\r\n/g, '\n');
}

try {
  const logContent = fs.readFileSync(logPath, 'utf-8');
  const lines = logContent.split('\n');
  
  let appliedCount = 0;
  
  for (const line of lines) {
    if (!line.trim()) continue;
    const step = JSON.parse(line);
    
    if (step.status !== 'DONE') continue;
    
    if (step.tool_calls) {
      for (const call of step.tool_calls) {
        if (call.name === 'replace_file_content' || call.name === 'multi_replace_file_content') {
          const args = typeof call.args === 'string' ? JSON.parse(call.args) : call.args;
          const target = cleanString(args.TargetFile || args.Target);
          
          if (target && target.includes('page.tsx')) {
            code = code.replace(/\r\n/g, '\n');
            
            if (call.name === 'replace_file_content') {
              const targetContent = cleanString(args.TargetContent);
              const replacementContent = cleanString(args.ReplacementContent);
              
              if (!code.includes(targetContent)) {
                console.error(`[Step ${step.step_index}] Error: Target content not found!`);
                continue;
              }
              
              code = code.replace(targetContent, replacementContent);
              console.log(`[Step ${step.step_index}] Applied replace_file_content`);
              appliedCount++;
            } else if (call.name === 'multi_replace_file_content') {
              let chunks = args.ReplacementChunks || [];
              if (typeof chunks === 'string') {
                try {
                  chunks = JSON.parse(chunks);
                } catch {}
              }
              
              let success = true;
              const cleanedChunks = chunks.map(chunk => ({
                TargetContent: cleanString(chunk.TargetContent),
                ReplacementContent: cleanString(chunk.ReplacementContent)
              }));
              
              // Apply chunks
              for (const chunk of cleanedChunks) {
                if (!code.includes(chunk.TargetContent)) {
                  console.error(`[Step ${step.step_index}] Error: Multi-chunk target content not found!`);
                  success = false;
                  break;
                }
              }
              
              if (success) {
                for (const chunk of cleanedChunks) {
                  code = code.replace(chunk.TargetContent, chunk.ReplacementContent);
                }
                console.log(`[Step ${step.step_index}] Applied multi_replace_file_content with ${cleanedChunks.length} chunks`);
                appliedCount++;
              }
            }
          }
        }
      }
    }
  }
  
  fs.writeFileSync(targetFilePath, code.replace(/\n/g, '\r\n'), 'utf-8');
  console.log(`\nSuccessfully applied ${appliedCount} edits. Recovered page.tsx!`);
} catch (err) {
  console.error('Failed to restore page.tsx:', err);
}
