async function run() {
  console.log("Asking Codex Sale text model about supported image models...");
  try {
    const res = await fetch("https://codex.sale/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": "Bearer sk-clb-3APylzCeyo_r4Lapmp_eLgQl5Ul973_z6QLyRWD1L1A",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-5.4-mini",
        messages: [
          {
            role: "user",
            content: "Please list the exact model identifiers (IDs) supported by the codex.sale API for image generation via the /v1/images/generations endpoint. (e.g. Dall-E, Flux, Stable Diffusion, etc.)"
          }
        ]
      })
    });
    console.log("Status:", res.status);
    const body = await res.json();
    console.log("Response:", body.choices?.[0]?.message?.content);
  } catch (err) {
    console.error("Error:", err);
  }
}
run();
