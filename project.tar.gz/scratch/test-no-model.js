async function run() {
  console.log("Calling Codex Sale Image Generation API without model parameter...");
  try {
    const payload = {
      prompt: "Flat modern infographic dashboard, 16:9, tech style, clean design.",
      n: 1,
      size: "1024x1024"
    };
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000); // 15s timeout
    
    const res = await fetch("https://codex.sale/v1/images/generations", {
      method: "POST",
      headers: {
        "Authorization": "Bearer sk-clb-3APylzCeyo_r4Lapmp_eLgQl5Ul973_z6QLyRWD1L1A",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    
    console.log("Status:", res.status);
    const body = await res.json();
    console.log("Body:", JSON.stringify(body, null, 2));
  } catch (err) {
    console.error("Error:", err.message);
  }
}
run();
