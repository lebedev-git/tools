server {
    listen 80;
    server_name tools.3321616.ru;

    location / {
        proxy_pass http://127.0.0.1:3010;
        proxy_connect_timeout 420s;
        proxy_send_timeout 420s;
        proxy_read_timeout 420s;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        client_max_body_size 50m;
    }
}
