async function run() {
  const url = "https://qwen.aikit.club/v1/images/generations";
  const key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjlhNzQzOTljLTcxMWYtNDA2MS05NWFjLTFkOGUxODY1NmZmZiIsImxhc3RfcGFzc3dvcmRfY2hhbmdlIjoxNzcwOTc1NTM5LCJleHAiOjE3ODIyODQ5MjV9.QoWCSkq07C7Q_cuxoGoL_BgaAkQ1MdhHu90vBN0JXeo";
  
  console.log(`Testing dall-e-3 on: ${url}...`);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${key}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "dall-e-3",
        prompt: "Flat modern infographic dashboard in minimalist dark mode style. Clean typography, business metrics blocks.",
        n: 1,
        size: "1024x1024"
      })
    });
    console.log("Status:", res.status);
    const body = await res.json();
    console.log("Body:", JSON.stringify(body, null, 2));
  } catch (err) {
    console.error("Error:", err.message);
  }
}
run();
