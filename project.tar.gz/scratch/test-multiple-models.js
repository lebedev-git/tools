async function run() {
  const models = [
    "dall-e-2",
    "stable-diffusion-xl",
    "stable-diffusion-3",
    "flux-schnell",
    "flux-dev",
    "flux-pro",
    "flux",
    "midjourney",
    "dall-e"
  ];

  for (const model of models) {
    console.log(`Trying model: '${model}'...`);
    try {
      const payload = {
        model: model,
        prompt: "A beautiful analytics dashboard in modern tech style, 16:9, showing stats for a digital product",
        n: 1,
        size: "1024x1024"
      };
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout
      
      const res = await fetch("https://codex.sale/v1/images/generations", {
        method: "POST",
        headers: {
          "Authorization": "Bearer sk-clb-3APylzCeyo_r4Lapmp_eLgQl5Ul973_z6QLyRWD1L1A",
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload),
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      console.log(`Status for '${model}':`, res.status);
      const body = await res.json();
      if (res.status === 200) {
        console.log(`SUCCESS with model '${model}':`, JSON.stringify(body, null, 2));
        break;
      } else {
        console.log(`Fail message for '${model}':`, body.error?.message || JSON.stringify(body));
      }
    } catch (err) {
      console.error(`Error for '${model}':`, err.message);
    }
    console.log("-----------------------------------------");
  }
}
run();
