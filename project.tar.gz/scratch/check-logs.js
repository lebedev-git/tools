const fs = require('fs');
const content = fs.readFileSync('C:\\DISK D\\Проекты\\tools\\lebedev-git-tools\\.next-dev-3000.log', 'utf8');
const lines = content.split('\n');
lines.forEach((line, idx) => {
  if (line.toLowerCase().includes('failed to generate') || line.toLowerCase().includes('imageapi') || line.toLowerCase().includes('image-2') || line.toLowerCase().includes('codex')) {
    console.log(`Line ${idx + 1}: ${line.trim()}`);
  }
});
