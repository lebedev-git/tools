const fs = require('fs');
const path = require('path');

async function run() {
  const logPath = 'C:\\Users\\Andey\\.gemini\\antigravity\\brain\\510cdccc-0a8b-429b-b35d-6ce89079d639\\.system_generated\\logs\\transcript.jsonl';
  console.log("Reading transcript.jsonl from", logPath);
  
  if (!fs.existsSync(logPath)) {
    console.error("Log file does not exist!");
    return;
  }
  
  const content = fs.readFileSync(logPath, 'utf8');
  const lines = content.split('\n');
  
  // We want to collect the file lines by line number
  const pageLines = {};
  
  for (const line of lines) {
    if (!line.trim()) continue;
    try {
      const step = JSON.parse(line);
      // We look for VIEW_FILE type steps or tool responses containing page.tsx contents
      if (step.type === 'VIEW_FILE' && step.content && step.content.includes('page.tsx')) {
        const fileContentStr = step.content;
        const matches = fileContentStr.matchAll(/(\d+): (.*)/g);
        for (const match of matches) {
          const lineNum = parseInt(match[1], 10);
          const lineContent = match[2];
          pageLines[lineNum] = lineContent;
        }
      }
    } catch (e) {
      // JSON parse error or matching error
    }
  }
  
  const sortedLineNums = Object.keys(pageLines).map(Number).sort((a, b) => a - b);
  console.log("Found lines count:", sortedLineNums.length);
  
  if (sortedLineNums.length === 0) {
    console.error("No page.tsx lines found in transcript.jsonl. Let's try searching for tool outputs.");
    // Backup search for step output in all lines
    const regex = /(\d+): (.*)/g;
    let match;
    while ((match = regex.exec(content)) !== null) {
      const lineNum = parseInt(match[1], 10);
      const lineContent = match[2];
      // Filter out if it doesn't look like page.tsx content
      if (lineNum <= 1439) {
        pageLines[lineNum] = lineContent;
      }
    }
    const backupLineNums = Object.keys(pageLines).map(Number).sort((a, b) => a - b);
    console.log("Backup search found lines:", backupLineNums.length);
  }
  
  if (Object.keys(pageLines).length > 0) {
    let finalContent = "";
    const maxLine = Math.max(...Object.keys(pageLines).map(Number));
    for (let i = 1; i <= maxLine; i++) {
      finalContent += (pageLines[i] !== undefined ? pageLines[i] : "") + "\n";
    }
    
    const outputPath = 'C:\\DISK D\\Проекты\\tools\\lebedev-git-tools\\apps\\web\\app\\page.tsx';
    fs.writeFileSync(outputPath, finalContent, 'utf8');
    console.log(`Successfully restored ${maxLine} lines to ${outputPath}`);
  } else {
    console.error("Could not find any lines to restore.");
  }
}

run();
