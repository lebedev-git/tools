async function run() {
  const url = "https://qwen.aikit.club/v1/models";
  const key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjlhNzQzOTljLTcxMWYtNDA2MS05NWFjLTFkOGUxODY1NmZmZiIsImxhc3RfcGFzc3dvcmRfY2hhbmdlIjoxNzcwOTc1NTM5LCJleHAiOjE3ODIyODQ5MjV9.QoWCSkq07C7Q_cuxoGoL_BgaAkQ1MdhHu90vBN0JXeo";
  
  console.log(`Fetching models from LLM provider: ${url}...`);
  try {
    const res = await fetch(url, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${key}`
      }
    });
    console.log("Status:", res.status);
    const body = await res.json();
    console.log("Body:", JSON.stringify(body, null, 2));
  } catch (err) {
    console.error("Error:", err.message);
  }
}
run();
