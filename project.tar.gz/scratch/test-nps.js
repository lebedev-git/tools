const yandexFormIds = {
  day1Input: "69b447a8e010db3d6b505b69",
  day1Output: "69b5762790fa7b47e155853c",
  day2: "69b5799f49af4761ee2057c6"
};

const token = "OAuth y0__xCGrufZBhjEm0AgibqbhReNTwlec-qB4RoeBDD4ffOerf6B-A";
const orgId = "bpf04hd74akq183mc4f5";

async function run() {
  const formId = yandexFormIds.day1Output;
  console.log("Fetching from Form:", formId);
  const response = await fetch(`https://api.forms.yandex.net/v1/surveys/${formId}/answers?page_size=1000`, {
    headers: {
      Accept: "application/json",
      "X-Cloud-Org-Id": orgId,
      "Authorization": token
    }
  });
  const data = await response.json();

  console.log("\nAnswers for day1 output on 2026-06-03:");
  data.answers.forEach((ans) => {
    const createdDate = new Date(ans.created).toISOString().split('T')[0];
    if (createdDate !== "2026-06-03") return;
    console.log(`Answer id: ${ans.id}, created: ${ans.created}`);
    ans.data.forEach((item, idx) => {
      console.log(`  [${idx}] (Col: ${data.columns[idx]?.text || idx}) value:`, item ? JSON.stringify(item.value) : "null");
    });
  });
}

run().catch(console.error);
