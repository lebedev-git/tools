const fs = require('fs');

const logPath = 'C:/Users/Andey/.gemini/antigravity/brain/510cdccc-0a8b-429b-b35d-6ce89079d639/.system_generated/logs/transcript.jsonl';
const content = fs.readFileSync(logPath, 'utf8');
const lines = content.split('\n');

for (const line of lines) {
  if (!line.trim()) continue;
  try {
    const step = JSON.parse(line);
    if (step.content && step.content.includes('Showing lines') && step.content.includes('page.tsx')) {
      console.log(`Step ${step.step_index}: type=${step.type}, source=${step.source}, hasContentLength=${step.content.length}`);
      // Print first 2 lines of content
      console.log("Snippet:", step.content.split('\n').slice(0, 5).join('\n'));
      console.log("------------------------");
    }
  } catch (e) {}
}
