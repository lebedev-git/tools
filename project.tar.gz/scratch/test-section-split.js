const patterns = {
  day1: /^\s*#+\s*(?:День\s*1)/i,
  day2: /^\s*#+\s*(?:День\s*2)/i,
  overall: /^\s*#+\s*(?:Общая\s*аналитика|Синтез|Синтез\s*результатов|Итоговая\s*аналитика)/i,
  products: /^\s*#+\s*(?:Продукты|Концепции|Концепции\s*продуктов|Цифровые\s*продукты)/i,
  infographic: /^\s*#+\s*(?:Инфографика|Дашборд|Разметка\s*для\s*дашборда|Разметка)/i
};

function extractSectionText(markdown, blockId) {
  const lines = markdown.split("\n");
  let startIdx = -1;
  let headerLevel = 1;

  const pattern = patterns[blockId];
  if (!pattern) return markdown;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (pattern.test(line)) {
      startIdx = i;
      const match = line.match(/^\s*(#+)/);
      if (match) {
        headerLevel = match[1].length;
      }
      break;
    }
  }

  if (startIdx === -1) {
    return markdown;
  }

  const sectionLines = [];
  sectionLines.push(lines[startIdx]);

  for (let i = startIdx + 1; i < lines.length; i++) {
    const line = lines[i];
    const headerMatch = line.match(/^\s*(#+)\s+/);
    if (headerMatch) {
      const level = headerMatch[1].length;
      if (level <= headerLevel) {
        break;
      }
    }
    sectionLines.push(line);
  }

  const sectionText = sectionLines.join("\n").trim();
  let cleanSectionText = sectionText;
  if (cleanSectionText.startsWith("#")) {
    const firstNewline = cleanSectionText.indexOf("\n");
    if (firstNewline !== -1) {
      cleanSectionText = cleanSectionText.slice(firstNewline + 1).trim();
    } else {
      cleanSectionText = "";
    }
  }
  return cleanSectionText || sectionText;
}

const mockMarkdown = `
# Введение
Некоторый текст введения.

## День 1
Текст для первого дня.
- Список 1
- Список 2

### Подраздел дня 1
Текст подраздела.

## День 2
Текст для второго дня.
- Список 3

# Общая аналитика
Текст общей аналитики.
`;

console.log("=== DAY 1 EXTRACT ===");
console.log(extractSectionText(mockMarkdown, "day1"));
console.log("\n=== DAY 2 EXTRACT ===");
console.log(extractSectionText(mockMarkdown, "day2"));
console.log("\n=== OVERALL EXTRACT ===");
console.log(extractSectionText(mockMarkdown, "overall"));
