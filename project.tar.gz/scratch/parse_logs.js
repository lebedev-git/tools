const fs = require('fs');
const logPath = 'C:\\Users\\Andey\\.gemini\\antigravity\\brain\\37ce5521-4b62-44e4-aa89-d75c2b8acf61\\.system_generated\\logs\\transcript.jsonl';

try {
  const content = fs.readFileSync(logPath, 'utf-8');
  const lines = content.split('\n');
  
  for (const line of lines) {
    if (!line.trim()) continue;
    const step = JSON.parse(line);
    if (step.step_index === 634 || step.step_index === 640) {
      console.log(`=== STEP ${step.step_index} ===`);
      const call = step.tool_calls[0];
      const args = typeof call.args === 'string' ? JSON.parse(call.args) : call.args;
      console.log('TargetContent length:', args.TargetContent ? args.TargetContent.length : 0);
      console.log('ReplacementContent length:', args.ReplacementContent ? args.ReplacementContent.length : 0);
      console.log('Is Target truncated?', args.TargetContent && args.TargetContent.includes('truncated'));
      console.log('Is Replacement truncated?', args.ReplacementContent && args.ReplacementContent.includes('truncated'));
      
      // Print first 500 chars of ReplacementContent
      if (args.ReplacementContent) {
        console.log('ReplacementContent preview:');
        console.log(args.ReplacementContent.substring(0, 800));
        console.log('...\n');
      }
    }
  }
} catch (err) {
  console.error(err);
}
