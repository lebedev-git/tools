const fs = require('fs');

async function run() {
  const logPath = 'C:/Users/Andey/.gemini/antigravity/brain/510cdccc-0a8b-429b-b35d-6ce89079d639/.system_generated/logs/transcript.jsonl';
  const content = fs.readFileSync(logPath, 'utf8');
  const lines = content.split('\n');
  
  const pageLines = {};
  
  for (const line of lines) {
    if (!line.trim()) continue;
    try {
      const step = JSON.parse(line);
      if (step.type === 'VIEW_FILE' && step.content) {
        const contentLines = step.content.split('\n');
        for (const cLine of contentLines) {
          const match = cLine.match(/^\s*(\d+): (.*)$/);
          if (match) {
            const lineNum = parseInt(match[1], 10);
            pageLines[lineNum] = true;
          }
        }
      }
    } catch (e) {}
  }
  
  const missing = [];
  for (let i = 1; i <= 1442; i++) {
    if (!pageLines[i]) {
      missing.push(i);
    }
  }
  console.log("Total missing lines count:", missing.length);
  console.log("Missing lines:", missing.slice(0, 100).join(", "));
}
run();
